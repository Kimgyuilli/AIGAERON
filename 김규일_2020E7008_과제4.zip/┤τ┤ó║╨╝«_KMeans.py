# 모듈 import
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score, silhouette_samples

# 데이터셋 가져오기
df = pd.read_csv('당뇨병.csv')

# 사용할 변수(혈당, 혈압)
X = df[['Glucose', 'BloodPressure']]

kmeans = KMeans(n_clusters=2, random_state=0)
kmeans.fit(X)

# 군집 결과를 데이터프레임에 추가
df['Cluster'] = kmeans.labels_

# 실루엣 계수
silhouette_avg = silhouette_score(X, kmeans.labels_)
print("평균 실루엣 계수 =", silhouette_avg)

silhouette_samples_values = silhouette_samples(X, kmeans.labels_)
silhouette_df = pd.DataFrame({'Cluster': kmeans.labels_, 'Silhouette': silhouette_samples_values})
print("군집별 실루엣 계수 평균:")
print(silhouette_df.groupby('Cluster')['Silhouette'].mean())

# 군집 시각화 (혈압, 혈당)
sns.scatterplot(data=df, x='BloodPressure', y='Glucose', hue='Cluster', style='Outcome', markers=["o", "s"])
plt.title("BloodPressure - Glucose")
plt.show()
