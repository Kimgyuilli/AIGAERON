# 필요한 라이브러리 임포트
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import seaborn as sns
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, recall_score, precision_score

# 한글 폰트
font_path = 'C:/Windows/Fonts/gulim.ttc'  # 사용할 폰트 경로
font_prop = fm.FontProperties(fname=font_path)
plt.rc('font', family=font_prop.get_name())  # 폰트 설정

# 학습 데이터
df = pd.read_csv('건강검진정보.csv')  # 학습용 데이터 
df = df.dropna()  # 결손치가 있는 행 제거
df = df.sample(n=50000, random_state=42)  # 랜덤 샘플링

print(df)

# 테스트 데이터
df_test = pd.read_csv('건강검진정보_test.csv')  # 테스트용 데이터
df_test.fillna(0, inplace=True)  # 결손치 채움

# 당뇨 위험 여부 생성 (식전혈당량 기준 100 초과)
df['당뇨위험'] = np.where(df['식전혈당(공복혈당)'] > 100, 1, 0)
df_test['당뇨위험'] = np.where(df_test['식전혈당(공복혈당)'] > 100, 1, 0)

# 데이터 준비
x_train = df[['수축기혈압', '이완기혈압', '성별코드', '연령대코드(5세단위)', '허리둘레', '신장(5cm단위)', '체중(5kg단위)']]
y_train = df['당뇨위험']

x_test = df_test[['수축기혈압', '이완기혈압', '성별코드', '연령대코드(5세단위)', '허리둘레', '신장(5cm단위)', '체중(5kg단위)']]  # 테스트 데이터 30개
y_test = df_test['당뇨위험'].iloc[:30]

# 데이터 탐색 및 시각화
sns.scatterplot(data=df, x='체중(5kg단위)', y='연령대코드(5세단위)', hue='당뇨위험')
plt.title("당뇨 상태에 따른 체중과 연령", fontproperties=font_prop)
plt.show()

# 모델 생성 및 학습 (KNN 알고리즘)
kn_model = KNeighborsClassifier(n_neighbors=3)  # 최근접 이웃을 3으로 설정
kn_model.fit(x_train, y_train)
# 모델 예측
kn_prd = kn_model.predict(x_test)

# 평가 결과 출력
print("==KNN 모델 평가==")
# 정확도, 재현율 및 정밀도 계산
print('정확도:', accuracy_score(y_test, kn_prd))
print('재현율:', recall_score(y_test, kn_prd, average='macro', zero_division=0))
print('정밀도:', precision_score(y_test, kn_prd, average='macro', zero_division=0))

# 예측값과 실제값 비교
compar = pd.DataFrame({'예측값': kn_prd, '실제값': y_test.values})
print(compar)