# 필요한 라이브러리 임포트
import pandas as pd
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, recall_score, precision_score, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# 한글 폰트
font_path = 'C:/Windows/Fonts/gulim.ttc'  # 사용할 폰트 경로
font_prop = fm.FontProperties(fname=font_path)
plt.rc('font', family=font_prop.get_name())  # 폰트 설정

# 학습 데이터 리드, 전처리
df = pd.read_csv('당뇨병.csv')  # 학습 데이터 로드
df = df.dropna()  # 결측치 제거

# 테스트 데이터 리드, 전처리
test_df = pd.read_csv('당뇨병_test.csv')  # 테스트 데이터 로드
test_df.fillna(0, inplace=True)  # 결측치 0으로 채움

# 학습 데이터 설정
X_train = df[['Glucose', 'Age', 'BMI', 'DiabetesPedigreeFunction']]
y_train = df['Outcome'] 

# 테스트 데이터 설정
X_test = test_df[['Glucose', 'Age', 'BMI', 'DiabetesPedigreeFunction']]
y_test = test_df['Outcome']

# 데이터 시각화
sns.scatterplot(data=df, x='BMI', y='Glucose', hue='Outcome')
plt.title("당뇨 상태에 따른 BIM와 혈당", fontproperties=font_prop)
plt.show()

# KNN 모델 생성 및 학습
knn_model = KNeighborsClassifier(n_neighbors=5)  # 최근접 이웃 수 설정
knn_model.fit(X_train, y_train)  # 모델 학습

# 예측
y_pred = knn_model.predict(X_test)

# 평가 결과
print("==KNN 모델 평가==")
print("정확도:", accuracy_score(y_test, y_pred))
print("재현율:", recall_score(y_test, y_pred, average='binary'))
print("정밀도:", precision_score(y_test, y_pred, average='binary'))

# 예측값, 실제값 비교
comparison = pd.DataFrame({'실제값': y_test.values, '예측값': y_pred})
print(comparison.head(10))
