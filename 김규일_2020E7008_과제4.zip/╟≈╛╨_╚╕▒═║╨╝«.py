# 모듈 import
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.neighbors import KNeighborsRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# 학습 데이터와 테스트 데이터 로드
train_df = pd.read_csv('당뇨병.csv')  # 학습 데이터 파일
test_df = pd.read_csv('당뇨병_test.csv')  # 테스트 데이터 파일

# 학습 데이터
x_train = train_df[['Age']]
y_train = train_df['BloodPressure']

# 테스트 데이터
x_test = test_df[['Age']]
y_test = test_df['BloodPressure']

# 표로 분포 확인
plt.figure(figsize=(16, 6))
plt.subplot(1, 3, 1)
plt.title('Age-BloodPressure')
sns.regplot(x='Age', y='BloodPressure', data=train_df)
plt.legend()

# K 최근접 이웃 회귀 모델 생성, 학습, 예측
KN_model = KNeighborsRegressor(n_neighbors=1)
KN_model.fit(x_train, y_train)
KN_prd = KN_model.predict(x_test)

plt.subplot(1, 3, 2)
# K 최근접 이웃 회귀 모델 예측 결과 시각화
plt.scatter(x_test, y_test, c='red', label='Real Values')
plt.scatter(x_test, KN_prd, c='blue', label='Predicted Values')
plt.xlabel('Age')
plt.ylabel('BloodPressure')
plt.title('KNN Age-BloodPressure')
plt.legend()

# K 최근접 이웃 회귀 모델 평가
mse_knn = mean_squared_error(y_test, KN_prd)
rmse_knn = np.sqrt(mse_knn)
r2_knn = r2_score(y_test, KN_prd)
score_knn = KN_model.score(x_test, y_test)

print('KNN Model Evaluation:')
print('MSE =', mse_knn)
print('RMSE =', rmse_knn)
print('R2 score =', r2_knn)
print('Score =', score_knn)

# 선형 회귀 모델 학습, 예측, 평가
LN_model = LinearRegression()
LN_model.fit(x_train, y_train)
LN_prd = LN_model.predict(x_test)

plt.subplot(1, 3, 3)
# 선형 회귀 모델 예측 결과 시각화
plt.scatter(x_test, y_test, c='red', label='Real Values')
plt.plot(x_test, LN_prd, c='blue', label='Regression Line')
plt.xlabel('Age')
plt.ylabel('BloodPressure')
plt.title('Linear Age-BloodPressure')
plt.legend()
plt.show()

# 선형 회귀 모델 평가
mse_line = mean_squared_error(y_test, LN_prd)
rmse_line = np.sqrt(mse_line)
r2_line = r2_score(y_test, LN_prd)
score_line = LN_model.score(x_test, y_test)

print('\n\n선형회귀 모델 Evaluation:')
print('MSE =', mse_line)
print('RMSE =', rmse_line)
print('r2 score =', r2_line)
print('Score =', score_line)
